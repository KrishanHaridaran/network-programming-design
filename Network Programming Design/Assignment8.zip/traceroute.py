import socket
import struct
import os
import time
import select
import binascii
import sys
import random

address = input("Enter Address to Traceroute : ")

def chksum(txt):
    # In this function we make the checksum of our packet
    txt = bytearray(txt)
    csum = 0
    countTo = (len(txt) // 2) * 2

    for count in range(0, countTo, 2):
        thisVal = txt[count+1] * 256 + txt[count]
        csum = csum + thisVal
        csum = csum & 0xffffffff

    if countTo < len(txt):
        csum = csum + str_[-1]
        csum = csum & 0xffffffff

    csum = (csum >> 16) + (csum & 0xffff)
    csum = csum + (csum >> 16)
    answer = ~csum
    answer = answer & 0xffff
    answer = answer >> 8 | (answer << 8 & 0xff00)
    return answer

def traceroute():
    
    port = random.choice((33000,35000))
    ttl = 1
    
    while ttl < 30:
        
        icmp_type = 8
        code = 0
        checksum = 0
        p_id = os.getpid()
        seq_num = 1

        empty_packet = struct.pack('B B H H H', icmp_type, code, checksum, p_id, seq_num)

        #Genrating some data 
        data = struct.pack('d',time.time())

        #Generating Checksum for packet+data using the above chksum function
        new_checksum = chksum(empty_packet+data)

        #Converting Checksum into network bit order
        if sys.platform == 'darwin':
            new_checksum = socket.htons(new_checksum) & 0xffff
        else:
            new_checksum = socket.htons(new_checksum)

        #Creating full packet with new_checksum
        packet = struct.pack('B B H H H', icmp_type, code, new_checksum, p_id, seq_num)

        #Generating a new packet using the same data 
        new_packet = (packet + data)

        #ICMP Packet Sending Socket
        c = socket.socket(socket.AF_INET,socket.SOCK_RAW,socket.IPPROTO_ICMP)
        c.setsockopt(socket.SOL_IP, socket.IP_TTL,ttl)
        c.sendto(new_packet,(address,1))

        ttl += 1


        #ICMP Reply Receiving Socket
        s = socket.socket(socket.AF_INET,socket.SOCK_RAW,socket.IPPROTO_ICMP)
        s.bind(('',port))
        addr = None

        try:

            data, addr = s.recvfrom(1024)

            s.close()
            c.close()

        except:
            pass


        if addr:
            if addr[0] != address:
                print('{:<4} {}'.format(ttl,addr[0]))
            elif addr[0] == address:
                print('{:<4} {}'.format(ttl,addr[0]))
                break
            else:
                print('{:<4} * * * *'.format(ttl))
                

traceroute()







