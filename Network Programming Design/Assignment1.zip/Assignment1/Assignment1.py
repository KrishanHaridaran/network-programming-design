sum = 0
x = None
print('\n** Simple calculator **')
print('__________________________')
print('\n -- Usage: Enter 0 to Exit the Programme\n')
try:
    while x != 0:
        x = int(input('Enter Number to Add : '))
        sum = sum+x
        print('Answer = ', sum)
except ValueError:
    print('\n Please Enter Numbers Only !')
    pass
except KeyboardInterrupt:
    print('\nClosing the Programme !!')
