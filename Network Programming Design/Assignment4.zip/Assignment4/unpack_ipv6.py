import struct
import socket

def unpack_ipv6(data):
    payload_length, next_head, hop_limit, sip, dip = struct.unpack('! 32x H B B 2Q 2Q', data[:40])

    return payload_length, next_header, hop_limit, sip, dip, data[40:]




