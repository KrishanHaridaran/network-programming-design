def unpack_udp(data):
    sport, dport, size = struct.unpack('! H H 2x H', data[:8])

    return sport, dport, size, data[8:]
