def unpack_ipv4(data):
    version_header_length = data[0]
    version = version_header_length >> 4
    header_length = (version_header_length & 15) * 4
    ttl , protocol, sourceip, targetip = struct.unpack('! 8x B B 2x 4s 4s', data[:20])

    def get_ipv4(addr):
       ip = ipaddress.IPv4Address(addr)
       return ip

    return version, header_length, ttl, protocol, get_ipv4(sourceip), get_ipv4(targetip), data[header_length:]
