import struct
import socket

def unpack_arp(data):
    h_type, p_type, h_a_length, p_a_length, opcode, send_addr, s_p_addr, target_addr, t_p_addr = struct.unpack('! H H
 B B H 3H 2H 3H 2H', data[:28])

    return  h_type, p_type, h_a_length, p_a_length, opcode, send_addr, s_p_addr, target_addr, t_p_addr, data[28:] 
