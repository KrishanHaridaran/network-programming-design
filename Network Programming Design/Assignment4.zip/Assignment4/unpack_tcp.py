def unpack_tcp(data):
    sport, dport, sequence, acknowledgement,offset_reserved_flags = struct.unpack('! H H L L H', data[:14])

    return sport, dport, sequence, acknowledgement, data[14:]
