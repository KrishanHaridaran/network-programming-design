def unpack_ethernet(raw_data):
    targetmac, sourcemac, proto = struct.unpack('! 6s 6s H', raw_data[:14])

    def get_mac(bytes_mac):
        mac = map('{:02x}'.format, bytes_mac)
        new_mac = ':'.join(mac).upper()
        return new_mac

    return get_mac(targetmac), get_mac(sourcemac), socket.htons(proto), raw_data[14:]
