import struct
import socket

def pack_arp(data):
    packet = struct.pack('! H H B B H 6s 4s 6s 4s', hdw_type, pro_type, hdw_adr_len, pro_adr_len, opcede, snd_hdw_adr, snd_pro_adr, trg_hdw_adr, trg_pro_adr)
