import struct
import socket

def pack_ethernet(data):
    packet = srtuct.pack('! 6s 6s H', dst_adr, src_sdr, length)
