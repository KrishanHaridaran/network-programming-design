import struct
import socket

def pack_tcp(data):
    packet = struct.pack('! H H L L B B H H H', sport, dport, seq, ack, hdr_len, flags, wdw, chksum, urg_ptr)
