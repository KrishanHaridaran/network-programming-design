import struct
import socket

def pack_ipv6(data):
    packet = struct.pack('! 2H H B B 8H 8H', vrs_trf_flw, pld_lng, nxt_hdr, hop_lmt, src_adr, dst_adr)
