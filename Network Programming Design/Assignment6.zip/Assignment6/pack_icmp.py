import struct
import socket

def pack_icmp():
    packet = struct.pack('! B B H', typ, code, chksm)
