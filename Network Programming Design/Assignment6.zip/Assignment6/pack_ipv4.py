import struct
import socket

"""ip_ver = 4
ip_vhl = 4

ip_ver_hl = (ip_ver << 4) + ip_vhl

ip_flags = 3
ip_offset = 13

ip_flag_offset = (ip_flag << 13) + ip_offset """

def pack_ipv4(data):
    packet = struct.pack('B B H H H B B H 4s 4s', ip_ver_hl, tos, tl, ide, ip_flag_offset, ttl, proto, checksum, sip, dip)

