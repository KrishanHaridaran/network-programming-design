import struct
import socket

def pack_udp(data):
    packet = struct.pack('! H H H H', sport, dport, length, checksum)
