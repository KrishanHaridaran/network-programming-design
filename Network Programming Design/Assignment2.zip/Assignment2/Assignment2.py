import sys
import argparse
import os.path

parser = argparse.ArgumentParser()
parser.add_argument("infile", help="the name of the file that you wish to dump", type=str)
parser.add_argument("outfile", help="the name of the file to print the output", type=str)
args = parser.parse_args()

try:
    with open(args.infile, "rb") as f:
        n = 0
        b = f.read(16)

        while b:
            s1 = " ".join([f"{i:02x}" for i in b])
            s1 = s1[0:23] + " " + s1[23:]
            width = 48
            s2 = "".join([chr(i) if 32 <= i <= 127 else "." for i in b])

            print(f"{n * 16:08x}  {s1:<{width}}  {s2}")
            
                                
            n += 1
            b = f.read(16)

            with open(args.outfile, "a+") as w:
                w.write(f"\n{n * 16:08x}  {s1:<{width}}  {s2}")

    print(f"{os.path.getsize(args.infile):08x}")
    
    

except Exception as e:
    print(__file__, ": ", type(e).__name__, " - ", e, sep="", file=sys.stderr)
