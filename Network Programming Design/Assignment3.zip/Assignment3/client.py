import socket
import threading
import time
import sys

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.connect((socket.gethostname(),10000))

try:
    def recv():
        msg = s.recv(1024)
        while msg:
            print('\nReceived:' + msg.decode())
            msg = s.recv(1024)

    def send():
        data = input('Message : ')
        while data:
            s.send(data.encode())
            data = input('\nMessage : ')

    t1 = threading.Thread(target=send)
    t1.deamon = True
    t1.start()
    time.sleep(1)
    t2 = threading.Thread(target=recv)  
    t2.deamon = True
    t2.start()
    time.sleep(1)
    #send()
    #recv()

except KeyboardInterrupt as e:
    print("Thankyou Good Bye !!!")
    s.close()
    sys.exit()
