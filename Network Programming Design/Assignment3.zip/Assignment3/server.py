import socket
import threading
import time
import sys

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind((socket.gethostname(), 10000))
s.listen(1)

client, addr = s.accept()

try:
    def send():
        print(f"[+] {addr[0]} Connected !!!")
        msg = input("Message : ")
        while msg:
            client.send(msg.encode())
            msg= input("\nMessage : ")

    def recv():
        msg = client.recv(1024)
        while msg:
            print('\nReceived:' + msg.decode())
            msg = client.recv(1024)

    t1 = threading.Thread(target=send)
    t1.deamon = True
    t1.start()
    time.sleep(1)
    t2 = threading.Thread(target=recv)
    t2.deamon = True
    t2.start()
    time.sleep(1)
    #recv()
    #send()

except KeyboardInterrupt as e:
    print("Thankyou Good Bye !!!")
    s.close()
    sys.exit()
    stop_threads = True




