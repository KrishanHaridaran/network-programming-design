import socket
import struct
import textwrap
import ipaddress

def main():
    try:
        s = socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.ntohs(0x0003))

        while True:
            raw_data, addr = s.recvfrom(65536)
            #print(raw_data)
            target, source, proto, data = unpack_ethernet(raw_data)
            print("\nEthernet Frame:")
            print(f"\tTarget : {target} | Source : {source} | Ether Type : {proto}")

            if proto == 8:
                version, header_length, ttl, protocol, sourceip, targetip, data = unpack_ipv4(data)
                print("\tIPv4 Packet:")
                print(f"\t\t Version : {version} | Header Legnth : {header_length} | TTL : {ttl}")
                print(f"\t\t Protocol : {protocol} | Sorce IP {sourceip} | Target IP {targetip}")

                if protocol == 1:
                    icmp_type, code, checksum, data = unpack_icmp(pack)
                    print("\tICMP Packet:")
                    print(f"\t\t Type : {icmp_type} | Code : {code} | Checksum : {checksum}")
                    print(f"\t\t\t{data}")

                elif protocol == 6:
                    sport, dport, sequence, acknowledgement, data = unpack_tcp(data)
                    print("\tTCP Packet:")
                    print(f"\t\t Source Port: {sport} | Destination Port : {dport} | Sequence : {sequence} | Acknowledgement : {acknowledgement}")
                    print(f"\t\t\t{data}")

                elif protocol == 17:
                    sport, dport, size, data = unpack_udp(data)
                    print("\tUDP Packet:")
                    print(f"\t\t Source Port : {sport} | Destination Port : {dport} | Length : {size}")
                    print(f"\t\t\t{data}")

            else :
                print(data)

    except KeyboardInterrupt as k:
        print ("Thank You Good Bye !!!")
        

def unpack_ethernet(raw_data):
    targetmac, sourcemac, proto = struct.unpack('! 6s 6s H', raw_data[:14])

    def get_mac(bytes_mac):
        mac = map('{:02x}'.format, bytes_mac)
        new_mac = ':'.join(mac).upper()
        return new_mac

    return get_mac(targetmac), get_mac(sourcemac), socket.htons(proto), raw_data[14:]

def unpack_ipv4(data):
    version_header_length = data[0]
    version = version_header_length >> 4
    header_length = (version_header_length & 15) * 4
    ttl , protocol, sourceip, targetip = struct.unpack('! 8x B B 2x 4s 4s', data[:20])

    def get_ipv4(addr):
       ip = ipaddress.IPv4Address(addr)
       return ip

    return version, header_length, ttl, protocol, get_ipv4(sourceip), get_ipv4(targetip), data[header_length:]

def unpack_icmp(data):
    icmp_type, code, checksum = struct.unpack('! B B H', data[:4])

    return icmp_type, code, checksum, data[4:]

def unpack_tcp(data):
    sport, dport, sequence, acknowledgement,offset_reserved_flags = struct.unpack('! H H L L H', data[:14])

    return sport, dport, sequence, acknowledgement, data[14:]

def unpack_udp(data):
    sport, dport, size = struct.unpack('! H H 2x H', data[:8])

    return sport, dport, size, data[8:]

main()
