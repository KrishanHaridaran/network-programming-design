import socket
import struct
import sys
import threading
import netifaces
import ipaddress
import time

#Opening the rules.txt file and reading it line by line

rules=[]
with open("rules.txt", 'r') as rules_file:
    data = rules_file.readline()
    while(data):
        rules.append(data.rstrip('\n').split(" "))
        #print(type(rules[0][1]))
        data = rules_file.readline()

#Checking Firewall rules for forwarding or denying packets

def rules_check(source_ip, source_port, destination_ip, destination_port):
    for rule in rules:
        if((source_ip==rule[0] or rule[0]=='any') and (source_port==rule[1] or rule[1]=='any') and (destination_ip==rule[2] or rule[2]=='any') and (destination_port==rule[3] or rule[3] == 'any')):
            return False
            break
    return True

#Getting the interface names using netifaces function

#interfaces = netifaces.interfaces()[1:]

#Create sending socket for all interfaces

s_s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
s_s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s_s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

#Creating receving socket seperately

r_s_1 = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0800))
r_s_1.bind(('ens33', 0))

r_s_2 = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0800))
r_s_2.bind(('ens34', 0))

#Rederecting all traffic to the sending socket

def s_1():
    while True:
        frame = r_s_1.recv(65535)
        send_packet(frame, 'ens33', r_s_1)
        
def s_2():
    while True:
        frame = r_s_2.recv(65535)
        send_packet(frame, 'ens34', r_s_2)
        
t1 = threading.Thread(target=s_1)
t2 = threading.Thread(target=s_2)

#Start all threads as daemons and close al of them

t1.setDaemon(True)
t1.start()
t2.setDaemon(True)
t2.start()


#Collect all the traffic and check for firewall rules

def send_packet(frame, int_name, socket_num):
    
    proto, src_ip, dst_ip = struct.unpack('!9xB2x4s4s',frame[14:34])
    src_ip = socket.inet_ntoa(src_ip)
    dst_ip = socket.inet_ntoa(dst_ip)
    print(src_ip,dst_ip)
        
    src_port = None
    dst_port = None

#Rederecting all traffic to the sending socket
    if proto==6:
        
        src_port, dst_port = struct.unpack('!HH16x',frame[34:54])
        src_port = str(src_port)
        dst_port = str(dst_port)
        
    
    elif proto==17:

        src_port, dst_port = struct.unpack('!HH4x', frame[34:42])
        #print(type(src_port),type(dst_port))
        src_port = str(src_port)
        dst_port = str(dst_port)
    
    if (rules_check(src_ip, src_port, dst_ip, dst_port)):
        try:
            s_s.sendto(frame[14:],(dst_ip,0))
        except PermissionError as p:
            pass
        except OSError as o:
            pass

def generate_slash_ani():
    print("\nMain Thread is Active ... ", end="")
    while (True):
        for x in "|/—\\":
            sys.stdout.write(x)
            sys.stdout.flush()
            time.sleep(0.2)
            sys.stdout.write('\b')

try:
    generate_slash_ani()
        
except KeyboardInterrupt as key_intrrupt:
    sys.exit()












